package com.ticket_support_automation_system.ticket_support_automation_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketSupportAutomationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
