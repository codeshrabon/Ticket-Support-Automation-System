package com.ticket_support_automation_system.ticket_support_automation_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketSupportAutomationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketSupportAutomationSystemApplication.class, args);
	}

}
